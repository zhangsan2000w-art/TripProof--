# TripProof Agent Skill 安装包

此 ZIP 面向**任意能读取 `SKILL.md` 并执行本地命令的 Agent**，不是 Codex 专用安装器，也不会修改目标 Agent 的配置。包内有一个统一入口 Skill、五个专门 Skill、原项目纯 Node.js JSON CLI 的副本、引用文档和许可证。

## 解压与注册

1. 将 ZIP 解压到目标机器任意固定目录；包内顶层为 `tripproof-agent-skill-1.0.0/`。
2. 将 `<解压目录>/tripproof-agent-skill-1.0.0/skills/tripproof/SKILL.md` 作为 Agent 的 Skill 入口。若目标框架扫描 Skill 目录，则把 `skills/` 内六个目录加入其 Skill 搜索路径；不同框架的注册方式以该框架说明为准。
3. 保留 `skills/tripproof/scripts/tripproof.mjs` 与各 `references/` 文件。统一入口本身可独立使用；专门 Skill 通过相邻的统一入口调用 CLI。
4. 目标机器安装 Node.js **22.18 或更高版本**。此 CLI 只用 Node 内置模块，不需要 `npm install`。验证：

   ```sh
   node /解压目录/tripproof-agent-skill-1.0.0/skills/tripproof/scripts/tripproof.mjs --help
   ```

## 连接 TripProof 服务

安装包只是 Agent 客户端，**不包含 TripProof 后端、数据库、模型或搜索服务**。须另行运行/部署完整 TripProof 网页和 worker，并配置服务端模型、搜索凭据。CLI 的 `health` 只验证服务/数据库基本可达，不保证上游凭据有效。

```sh
export TRIPPROOF_URL='https://your-tripproof.example'  # HTTP(S) 根地址
export TRIPPROOF_SESSION_PATH='/安全目录/该用户专用-session.json'
# 若服务开启入口密码：export TRIPPROOF_PASSWORD='...'；不要写进 Skill 或命令参数
node /解压目录/tripproof-agent-skill-1.0.0/skills/tripproof/scripts/tripproof.mjs health
```

`TRIPPROOF_SESSION_PATH` 必须按用户或 Agent 会话隔离；CLI 保存 owner/入口 Cookie，不要提交或共享该文件。若 Agent 在另一台机器运行，`TRIPPROOF_URL` 应指向它能访问的服务器，不能依赖服务器本机的 `127.0.0.1`。在公开网络上使用 HTTPS。

CLI 成功输出单行 JSON；失败向 stderr 输出 JSON 并返回非零退出码。异步任务须检查 `run.status`，不能仅凭命令成功就宣称核验完成。提取/搜索会产生上游费用，创建/消息/修复会写入数据；按 Skill 中的确认要求执行。分享链接可能公开创建时附上的原攻略。

## 包内结构

```text
tripproof-agent-skill-1.0.0/
├── README.md                         本文件
├── LICENSE                           原项目许可证
├── skills/
│   ├── tripproof/
│   │   ├── SKILL.md                   统一入口
│   │   ├── references/agent-interface.md
│   │   └── scripts/tripproof.mjs      随包 JSON CLI
│   ├── tripproof-intake/
│   ├── tripproof-investigation/
│   ├── tripproof-repair/
│   ├── tripproof-notice/
│   └── tripproof-alternatives/
└── docs/                             能力图、交互清单、拆分设计
```

如果只需一个 Skill，保留整个 `skills/tripproof/` 目录即可；它的 `references/agent-interface.md` 列出全部 CLI 命令。升级时应从同一源码版本重新打包 CLI 与文档，避免接口漂移。
